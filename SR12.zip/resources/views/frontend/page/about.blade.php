@extends ('frontend/layout.app')
@section ('title', 'Herbal Skincare')

@section ('content')
about
@endsection