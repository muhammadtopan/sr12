<!DOCTYPE html>
<html lang="en">
<head>
    <title>sr12herbalstore.com</title>
</head>
<body>
    <p>Hai {{ $data['name'] }}</p>
    <p>Berikut katalog SR12 Herbal Store</p>
    <p>Thanks!</p>
</body>
</html>