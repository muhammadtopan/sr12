<aside class="control-sidebar control-sidebar-dark">
</aside>
<footer class="main-footer">
    Copyright &copy; <script>
        document.write(new Date().getFullYear());
    </script> <a href="" target="_blank" style="color: #B9BABC">SR12</a> | <i class="fa fa-heart-o" aria-hidden="true"></i> by Taufano.  
</footer><?php /**PATH D:\PROJECT\SR12\resources\views/backend/component/footer.blade.php ENDPATH**/ ?>