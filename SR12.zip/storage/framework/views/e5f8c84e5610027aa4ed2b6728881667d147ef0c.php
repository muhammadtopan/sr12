
<?php $__env->startSection('title', 'Herbal Skincare'); ?>

<?php $__env->startSection('content'); ?>
contact
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\SR12\resources\views/frontend/page/contact.blade.php ENDPATH**/ ?>