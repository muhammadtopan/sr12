
<?php $__env->startSection('title', 'Herbal Skincare'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Hero Section Begin -->
    <section class="hero-section">
        <div class="hero-items owl-carousel">
            <div class="single-hero-items set-bg" data-setbg="<?php echo e(asset('frontend/img/time-bg.jpg')); ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-7">
                            <span>We're present.....</span>
                            <h4>SR12 Herbal Skincare By. Spotlight Team Mempersembahkan Marketplace Pertama Produk SR12 Herbal Skincare di Seluruh Daerah Di Indonesia.....</h4>
                            <span>SIAPAPUN BISA BISNIS ONLINE DISINI DENGAN BENEFIT YANG LUAR BIASA</span> 
                            <!-- <a href="#" class="primary-btn">Shop Now</a> -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-hero-items set-bg" data-setbg="<?php echo e(asset('frontend/img/time-bg.jpg')); ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-7">
                            <span>We're present.....</span>
                            <h4>SR12 Herbal Skincare By. Spotlight Team Mempersembahkan Marketplace Pertama Produk SR12 Herbal Skincare di Seluruh Daerah Di Indonesia.....</h4>
                            <span>SIAPAPUN BISA BISNIS ONLINE DISINI DENGAN BENEFIT YANG LUAR BIASA</span>
                            <!-- <a href="#" class="primary-btn">Shop Now</a> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Banner Section Begin -->
    <div class="banner-section spad">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="kategori owl-carousel">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-banner">
                                <img src="<?php echo e(asset('frontend/img/kotak.png')); ?>" alt="">
                                <div class="inner-text">
                                    <h6><?php echo e($kategori->category_name); ?></h6>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner Section End -->

    <!-- Semua Produk -->
    <section class="women-banner spad">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-6">
                            <h4>PRODUK</h4>
                        </div>
                        <div class="col-6">
                            <div class="filter-control text-right">
                                <ul class="section-tab-nav tab-nav">
                                    <li id="allproduct"><a href="<?php echo e(('shop.product')); ?>">Lihat Semua </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="allproduct-slider owl-carousel">
                        <?php $__currentLoopData = $allproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $product10): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- <div class="col-lg-3 col-sm-6"> -->
                            <div class="product-item">
                                <div class="pi-pic">
                                    <a href="<?php echo e(route('detail_product',$product10->product_id)); ?>">
                                        <img src="<?php echo e(asset('lte/dist/img/product/' . $product10->product_image )); ?>" alt="">
                                    </a>
                                    <ul>
                                        <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                        <!-- <li class="quick-view"><a href="<?php echo e(route('detail_product',$product10->product_id)); ?>">+ Quick View</a></li> -->
                                        <!-- <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li> -->
                                    </ul>
                                </div>
                                <div class="pi-text">
                                    <div class="catagory-name"><?php echo e($product10->category_name); ?></div>
                                    <a href="#">
                                        <h5><?php echo e($product10->product_name); ?></h5>
                                    </a>
                                    <div class="product-price">
                                        Rp <?php echo e(number_format($product10->product_price)); ?>

                                    </div>
                                </div>
                            </div>
                        <!-- </div> -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Semua Produk -->

    <!-- Women Banner Section Begin -->
    <section class="women-banner spad">
        <div class="container-fluid">
            <div class="row">
                <div class="col-6">
                    <h4>PRODUK</h4>
                </div>
                <div class="col-6">
                    <div class="filter-control text-right">
                        <ul class="section-tab-nav tab-nav">
                            <li id="allproduct"><a href="<?php echo e(('shop.product')); ?>">Lihat Semua </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="product-large set-bg" data-setbg="<?php echo e(asset('frontend/img/products/women-large.jpg')); ?>">
                        <h4>Best Seller</h4>
                        <a href="#">Lihat Semua</a>
                    </div>
                </div>
                <div class="col-lg-9 offset-lg-1">
                    <div class="product-slider owl-carousel">
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $product1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-item">
                                <div class="pi-pic">
                                    <a href="<?php echo e(route('detail_product',$product1->product_id)); ?>">
                                        <img src="<?php echo e(asset('lte/dist/img/product/' . $product1->product_image )); ?>" alt="">
                                    </a>
                                    <ul>
                                        <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                        <!-- <li class="quick-view"><a href="<?php echo e(route('detail_product',$product1->product_id)); ?>">+ Quick View</a></li> -->
                                        <!-- <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li> -->
                                    </ul>
                                </div>
                                <div class="pi-text">
                                    <div class="catagory-name"><?php echo e($product1->category_name); ?></div>
                                    <a href="#">
                                        <h5><?php echo e($product1->product_name); ?></h5>
                                    </a>
                                    <div class="product-price">
                                        Rp <?php echo e(number_format($product1->product_price)); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Women Banner Section End -->


    <!-- Women Banner Section Begin -->
    <section class="women-banner spad">
        <div class="container-fluid">
            <div class="row">
                <div class="col-6">
                    <h4>PRODUK</h4>
                </div>
                <div class="col-6">
                    <div class="filter-control text-right">
                        <ul class="section-tab-nav tab-nav">
                            <li id="allproduct"><a href="<?php echo e(('shop.product')); ?>">Lihat Semua </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="product-large set-bg" data-setbg="<?php echo e(asset('frontend/img/products/man-large.jpg')); ?>">
                        <h4>New Product</h4>
                        <a href="#">Lihat Semua</a>
                    </div>
                </div>
                <div class="col-lg-9 offset-lg-1">
                    <div class="product-slider owl-carousel">
                        <?php $__currentLoopData = $productnew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $product2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-item">
                                <div class="pi-pic">
                                    <a href="<?php echo e(route('detail_product',$product2->product_id)); ?>">
                                        <img src="<?php echo e(asset('lte/dist/img/product/' . $product2->product_image )); ?>" alt="">
                                    </a>
                                    <ul>
                                        <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                        <!-- <li class="quick-view"><a href="<?php echo e(route('detail_product',$product2->product_id)); ?>">+ Quick View</a></li> -->
                                        <!-- <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li> -->
                                    </ul>
                                </div>
                                <div class="pi-text">
                                    <div class="catagory-name"><?php echo e($product2->category_name); ?></div>
                                    <a href="#">
                                        <h5><?php echo e($product2->product_name); ?></h5>
                                    </a>
                                    <div class="product-price">
                                        Rp <?php echo e(number_format($product2->product_price)); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Women Banner Section End -->

    <!-- Blog Details Section Begin -->
    <!-- <section>
        <div class="container contact-section spad">
            <div class="row">
                <div class="col-1">
                </div>
                <div class="col-10">
                    <div class="blog-more">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="contact-title">
                                    <h4>Testimoni</h4>
                                </div>
                            </div>
                            <?php $__currentLoopData = $testimony; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $testimonies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-sm-4">
                                    <a href="<?php echo e(route('testimon', $testimonies->testimony_id)); ?>">
                                        <img src="<?php echo e(asset('lte/dist/img/testimony/' . $testimonies->testimony_gambar )); ?>" alt="">
                                        <h5><?php echo e(Str::limit($testimonies->testimony_judul,50)); ?></h5>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Blog Details Section End -->

    <!-- Instagram Section Begin -->
    <div class=" instagram-photo">
        <?php $__currentLoopData = $testimony; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $testimonies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="insta-item set-bg" data-setbg="<?php echo e(asset('lte/dist/img/testimony/' . $testimonies->testimony_gambar )); ?>">
                <div class="inside-text">
                    <!-- <i class="ti-instagram"></i> -->
                    <h5 class="text-light">Testimoni</h5>
                    <h5><a href="#"><?php echo e(Str::limit($testimonies->testimony_judul,50)); ?></a></h5>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- Instagram Section End -->

    <!-- Man Banner Section Begin -->
    <!-- <section class="man-banner spad">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8">
                    <div class="filter-control">
                        <ul>
                        <li id="allproduct" class="active">All <a data-toggle="tab" href="#allproduct"></a></li>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $categories2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li id="li<?php echo e($categories2->category_id); ?>">
                                    <a data-toggle="tab" href="#<?php echo e($categories2->category_id); ?>">
                                    <?php echo e($categories2->category_name); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="product-slider owl-carousel">
                        <?php $__currentLoopData = $productnew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $product2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-item">
                                <div class="pi-pic">
                                    <a href="<?php echo e(route('detail_product',$product2->product_id)); ?>">
                                        <img src="<?php echo e(asset('lte/dist/img/product/' . $product2->product_image )); ?>" alt="">
                                    </a>
                                    <ul>
                                        <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                        <li class="quick-view"><a href="#">+ Quick View</a></li>
                                        <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                    </ul>
                                </div>
                                <div class="pi-text">
                                    <div class="catagory-name"><?php echo e($product2->category_name); ?></div>
                                    <a href="#">
                                        <h5><?php echo e($product2->category_name); ?></h5>
                                    </a>
                                    <div class="product-price">
                                        <?php echo e($product2->product_price); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-lg-3 offset-lg-1">
                    <div class="product-large set-bg m-large" data-setbg="<?php echo e(asset('frontend/img/products/man-large.jpg')); ?>">
                        <h2>New Poduct</h2>
                        <a href="#">Discover More</a>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Man Banner Section End -->

    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">Large modal</button> -->
    
    <div class="modal fade bd-example-modal-lg" id="quickView" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    ...
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\SR12\resources\views/frontend/page/home.blade.php ENDPATH**/ ?>