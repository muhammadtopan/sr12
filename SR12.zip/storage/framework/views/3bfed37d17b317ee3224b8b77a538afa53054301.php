
<?php $__env->startSection('title', 'Herbal Skincare'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                    <a href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i> Home</a>
                        <span>Profile <?php echo e($akun->costumer_name); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->

    <!-- Shopping Cart Section Begin -->
    <section class="checkout-section spad">
        <div class="container">
            <form action="#" class="checkout-form">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h4>Profile</h4>
                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-12">
                                <label for="costumer_name">Nama</label>
                                <input type="text" id="costumer_name" name="costumer_name" value="<?php echo e($akun->costumer_name); ?>" readonly>
                            </div>
                            <div class="col-lg-12">
                                <label for="costumer_email">Email</label>
                                <input type="text" id="costumer_email" name="costumer_email" value="<?php echo e($akun->costumer_email); ?>" readonly>
                            </div>
                            <div class="col-lg-12">
                                <label for="costumer_phone">Telepon</label>
                                <input type="text" id="costumer_phone" name="costumer_phone" value="<?php echo e($akun->costumer_phone); ?>" readonly>
                            </div>
                            <div class="col-lg-12 group-input">
                                <label for="costumer_gender">Jenis Kelamin</label>
                                <select name="costumer_gender" id="costumer_gender" class="form-control <?php $__errorArgs = ['costumer_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                    <option value="LK" <?php echo ($akun->costumer_gender == 'LK') ? 'selected' : '' ?>>Laki-laki</option>
                                    <option value="PR" <?php echo ($akun->costumer_gender == 'PR') ? 'selected' : '' ?>>Perempuan</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="col-lg-12">
                            <label for="prov_id">Provinsi</label>
                            <input type="text" id="prov_id" name="prov_id" value="<?php echo e($akun->prov_nama); ?>" readonly>
                        </div>
                        <div class="col-lg-12">
                            <label for="kota_id">Kota/Kab</label>
                            <input type="text" id="kota_id" name="kota_id" value="<?php echo e($akun->kota_nama); ?>" readonly>
                        </div>
                        <div class="col-lg-12">
                            <label for="costumer_address">Alamat</label>
                            <input type="text" id="costumer_address" name="costumer_address" value="<?php echo e($akun->costumer_address); ?>" readonly>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <!-- Shopping Cart Section End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\SR12\resources\views/frontend/costumer/profile.blade.php ENDPATH**/ ?>