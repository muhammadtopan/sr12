
<?php $__env->startSection('title', 'Dashboard Vendor'); ?>

<?php $__env->startSection('content'); ?>

Selamat Datang <?php echo e($name); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\SR12\resources\views/frontend/vendor/index.blade.php ENDPATH**/ ?>