
<?php $__env->startSection('title', 'Vendor List'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Stock Product</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Stock Product</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card card-tabs">
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <strong><?php echo e(session()->get('message')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                        </div>
                    <?php endif; ?>
                    <div class="card-header bg-dark p-0 pt-1">
                        <ul class="nav nav-tabs" id="custom-tabs-two-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="verifikasi-tab" data-toggle="pill" href="#verifikasi" role="tab" aria-controls="custom-tabs-two-home" aria-selected="true">Stock</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="belum-verifikasi-tab" data-toggle="pill" href="#belum-verifikasi" role="tab" aria-controls="belum-verifikasi" aria-selected="false">Stock Kosong</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="tab-content" id="custom-tabs-two-tabContent">

                            
                            <div class="tab-pane fade show active" id="verifikasi" role="tabpanel" aria-labelledby="verifikasi-tab">
                                <table id="zero_config" class="table table-bordered table-hover">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>No</th>
                                            <th>Product</th>
                                            <th>Stock</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $stocks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                            <td class="text-center">
                                                <!-- <img src="<?php echo e(asset('lte/dist/img/product/' . $stocks->product_image )); ?>" alt="homepage" class="light-logo" style="width: 10em;"> <br> -->
                                                <?php echo e($stocks->product_name); ?>

                                            </td>
                                            <td class="text-center">
                                                <div class="col-lg-3">
                                                    <div class="form-group">
                                                        <input type="number" min="0" class="form-control" name="stock_input<?php echo e($stocks->product_id); ?>" id="stock_input<?php echo e($stocks->product_id); ?>" value="<?php echo e($stocks->product_stok); ?>">
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <button data-input="<?php echo e($stocks->product_id); ?>" class="btn btn-sm btn-dark my-4" onclick="update_stok(this, '<?php echo e($stocks->stok_id); ?>','<?php echo e(route("stock.update")); ?>', '<?php echo e($stocks->product_id); ?>')">
                                                    <i class="fa fa-edit .text-white" style="color: #fff !important"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            
                            <div class="tab-pane fade" id="belum-verifikasi" role="tabpanel" aria-labelledby="belum-verifikasi-tab">
                                <table id="zero_config" class="table table-bordered table-hover">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>No</th>
                                            <th>Product</th>
                                            <th>Stock</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $stok0; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor => $stoksnull): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <tr>
                                            <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                            <td class="text-center">
                                                <!-- <img src="<?php echo e(asset('lte/dist/img/product/' . $stoksnull->product_image )); ?>" alt="homepage" class="light-logo" style="width: 10em;"> <br> -->
                                                <?php echo e($stoksnull->product_name); ?>

                                            </td>
                                            <td class="text-center">
                                            <div class="col-3">
                                                    <div class="form-group">
                                                        <input type="number" min="0" class="form-control" name="stock_input<?php echo e($stoksnull->product_id); ?>" id="stock_input<?php echo e($stoksnull->stok_id); ?>" value="<?php echo e($stoksnull->product_stok); ?>">
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <button data-input="<?php echo e($stoksnull->stok_id); ?>" class="btn btn-sm btn-dark my-4" onclick="update_stok(this, '<?php echo e($stoksnull->stok_id); ?>','<?php echo e(route("stock.update")); ?>', '<?php echo e($stoksnull->product_id); ?>')">
                                                    <i class="fa fa-edit .text-white" style="color: #fff !important"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<script>
    async function update_stok(e,stok_id,route) {
        // console.log(stok_id);
        var stock_value = document.getElementById(`stock_input${e.dataset.input}`).value;
        console.log(stock_value);
        let data = await axios.post("<?php echo e(route('stock.update')); ?>",{stock_id: stok_id, product_stok: stock_value})
        toastr.success(data.data.message)
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend/layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\SR12\resources\views/frontend/vendor/stock.blade.php ENDPATH**/ ?>