
<?php $__env->startSection('title', 'Herbal Skincare'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Blog Details Section Begin -->
    <section class="blog-details contact-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="contact-title">
                        <h4>Testimoni</h4>
                    </div>
                    <div class="blog-details-inner">
                        <div class="blog-detail-title">
                            <h2><?php echo e($testimony->testimony_judul); ?></h2>
                            <p> <?php echo e($testimony->testimony_category); ?> </p>
                        </div>
                        <div class="blog-large-pic">
                            <img src="<?php echo e(asset('lte/dist/img/testimony/' . $testimony->testimony_gambar )); ?>" alt="">
                        </div>
                        <div class="container contact-section spad">
                            <div class="row">
                                <div class="col-1">
                                </div>
                                <div class="col-10">
                                    <div class="blog-more">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="contact-title">
                                                    <h4>Testimoni Lainnya</h4>
                                                </div>
                                            </div>
                                            <?php $__currentLoopData = $testimonyss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $testimonies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-sm-4">
                                                    <a href="<?php echo e(route('testimon', $testimonies->testimony_id)); ?>">
                                                        <img src="<?php echo e(asset('lte/dist/img/testimony/' . $testimonies->testimony_gambar )); ?>" alt="">
                                                        <h5><?php echo e(Str::limit($testimonies->testimony_judul,50)); ?></h5>
                                                    </a>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Blog Details Section End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\SR12\resources\views/frontend/page/testimony.blade.php ENDPATH**/ ?>