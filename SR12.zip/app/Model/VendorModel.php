<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class VendorModel extends Model
{
    protected $table = "tb_vendor";
    protected $primaryKey = "user_id";
}
